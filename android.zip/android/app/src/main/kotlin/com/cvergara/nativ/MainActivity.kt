package com.cvergara.nativ

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
